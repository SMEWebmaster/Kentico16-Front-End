# template-images

This is where images tied to the basic design of the site would be kept.
This would include background images, permanent icons, etc.