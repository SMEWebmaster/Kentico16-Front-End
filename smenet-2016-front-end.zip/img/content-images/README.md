# content-images

This is where client editable images are kept.
This would include in-content images for articles, profiles, etc.
