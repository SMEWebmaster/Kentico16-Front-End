# starterGulp

This is the basic structure for a new build.

!NPM should be installed globally!

1. Open the command line from this folder
2. Type "npm install" and hit Enter
3. All dependencies should then be installed based on the requirements listed in package.json
4. There will be small errors during this install. These should be ok unless an error comes up which stops the install.
5. If any errors come up which stop the install, this is usually due to missing global dependencies. Install any dependencies outlined in the error and proceed again

