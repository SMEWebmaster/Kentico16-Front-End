'use strict';
/*****************************************
    Variables
******************************************/
//Dependency Variables
var autoprefixer = require('gulp-autoprefixer'),
   base64 = require('gulp-css-base64'),
   bs = require('browser-sync').create(),
   cached = require('gulp-cached'),
   changed = require('gulp-changed'),
   csso = require('gulp-csso'),
   concat = require('gulp-concat'),
   del = require('del'),
   gulp = require('gulp'),
   gulpif = require('gulp-if'),
   jshint = require('gulp-jshint'),
   minify = require('gulp-minify'),
   notify = require('gulp-notify'),
   plumber = require('gulp-plumber'),
   pug = require('gulp-pug'),
   pugInheritance = require('gulp-pug-inheritance'),
   runSequence = require('run-sequence'),
   sass = require('gulp-sass'),
   sourcemaps = require('gulp-sourcemaps');

//Browsersync Variables
var reload = bs.reload,
   sitePort = Math.floor(Math.random() * (49150 - 1024 + 1)) + 1024,
   uiPort = sitePort + 1;

//Conditional Varaibles
var browserSyncActive = false,
   buildForProduction = false;

//Build Path Variables
var jsDistPath = './dist/js/front-end',
   cssDistPath = './dist/style/css',
   fontDistPath = './dist/fonts',
   htmlDistPath = './dist',
   imgDistPath = './dist/img';


/*****************************************
JavaScript Tasks
******************************************/
//Delete old compiled JS
gulp.task('cleanJS', function() {
   return del('js/front-end/frontEnd*.js');
});
//Lint JS Files Mid Stream
gulp.task('lintJS-stream', ['cleanJS'], function() {
   return gulp.src([
         'js/front-end/*.js',
         '!js/**/jquery-*.js',
         '!js/**/frontEnd*.js'
      ])
      .pipe(jshint())
      .pipe(jshint.reporter('jshint-stylish'));
});
//Conconate JS
gulp.task('concatJS', ['lintJS-stream'], function() {
   return gulp.src(['js/front-end/jquery*.js',
         'js/front-end/*.js',
         '!js/**/frontEnd*.js'
      ])
      .pipe(plumber({ errorHandler: notify.onError('<%= error.message %>') }))
      .pipe(concat('frontEnd.js'))
      .on('error', function(err) {
         new Error(err);
      })
      .pipe(plumber.stop())
      .pipe(gulp.dest('./js/front-end'))
      .pipe(gulpif(buildForProduction, gulp.dest(jsDistPath)));
});
//Minify JS
gulp.task('minifyJS', ['concatJS'], function() {
   return gulp.src('js/front-end/frontEnd.js')
      .pipe(plumber({ errorHandler: this.emit('end') }))
      .pipe(minify({
         noSource: true,
         mangle: false
      }))
      .on('error', notify.onError(function(error) {
         return "There was a problem with your JavaScript, and the file was not minified. \nHint: See CMD window for details'.";
      }))
      .pipe(plumber.stop())
      .pipe(gulp.dest('./js/front-end'))
      .pipe(gulpif(buildForProduction, gulp.dest(jsDistPath)))
      .pipe(gulpif(browserSyncActive, bs.stream()));
});



/*****************************************
    SCSS/CSS Tasks
******************************************/
// Delete old compiled CSS
gulp.task('cleanCSS', function() {
   return del('style/css/**');
});
// Compile SCSS, Prefix, Write Sourcemap
gulp.task('compileCSS', ['cleanCSS'], function() {
   return gulp.src(['style/scss/**/*.scss'])
      .pipe(plumber({ errorHandler: notify.onError('<%= error.message %>') }))
      .pipe(sourcemaps.init())
      .pipe(sass({ outputStyle: 'compressed' }).on('error', function(err) {
         new Error(err);
      }))
      .pipe(autoprefixer({
         browsers: ['last 2 versions'],
         cascade: false
      }))
      .pipe(sourcemaps.write('./'))
      .pipe(plumber.stop())
      .pipe(gulp.dest('style/css'))
      .pipe(gulpif(buildForProduction, gulp.dest(cssDistPath)))
      .pipe(gulpif(browserSyncActive, bs.stream({ match: '**/*.css' })));
});



/*****************************************
    PUG Tasks
******************************************/
//Compile changed PUG files to and push to browser
gulp.task('compileChangedPUG', function() {
   return gulp.src(['pug/**/*.pug'])
      .pipe(plumber({ errorHandler: notify.onError('<%= error.message %>') }))
      .pipe(changed('./', { extension: '.html' }))
      .pipe(gulpif(global.isWatching, cached('pug')))
      .pipe(pugInheritance({ basedir: './pug', skip: 'node_modules' }))
      .pipe(pug({
         pretty: true,
         notify: false
      }))
      .pipe(plumber.stop())
      .pipe(gulp.dest('./'));
});
//Push changed pug files to the browser after it has compiled
gulp.task('pushPUG', ['compileChangedPUG'], function() {
   return gulp.src(['pug/**/*.pug'])
      .pipe(gulpif(browserSyncActive, bs.stream({ once: true })));
});
//set global watching variable
gulp.task('setWatch', function() {
   global.isWatching = true;
});

//Delete old compiled HTML files
gulp.task('cleanPUG', function() {
   return del(['./*.html', './includes/*.html']);
});
//Compile Remaining PUG files to HTML
gulp.task('compileAllPUG', ['cleanPUG'], function() {
   return gulp.src(['pug/**/*.pug'])
      .pipe(plumber({ errorHandler: notify.onError('<%= error.message %>') }))
      .pipe(pug({
         pretty: true,
         notify: false
      }))
      .pipe(plumber.stop())
      .pipe(gulp.dest('./'))
      .pipe(gulpif(buildForProduction, gulp.dest(htmlDistPath)));
});



/*****************************************
    BrowserSync & Watch Tasks
******************************************/
//Browsersync watch and serve changes
gulp.task('serve', ['compileCSS', 'minifyJS', 'setWatch', 'compileAllPUG', ], function() {
   browserSyncActive = true;
   bs.init({
      notify: false,
      server: {
         baseDir: './'
      },
      port: sitePort,
      ui: {
         port: uiPort
      }
   });
   gulp.watch('style/**/*.scss', ['compileCSS']);
   gulp.watch(['js/**', '!js/front-end/frontEnd*.js'], ['minifyJS']);
   gulp.watch('pug/**/*.pug', ['pushPUG']);
});
//Default gulp task start watching
gulp.task('default', ['serve']);



/*****************************************
    Linting Tasks (Run Individually)
******************************************/
//Lint CSS
gulp.task('lintCSS', function() {
   return gulp.src('refactor/**/*.css')
      .pipe(csso({
         restructure: false,
         sourceMap: true,
         debug: true
      }))
      .pipe(gulp.dest('refactor/optimized/style'));
});



/*****************************************
    Gulp Build (Create Production Folder)
******************************************/
//delete old dist folder
gulp.task('cleanDist', function() {
   return del('./dist');
});
gulp.task('moveImages', function() {
   return gulp.src(['img/**'], {base: './'})
      .pipe(gulp.dest(imgDistPath));
});
gulp.task('moveFonts', function() {
   return gulp.src(['fonts/**'], {base: './'})
      .pipe(gulp.dest(fontDistPath));
});
//build task to create dist folder for devs
gulp.task('build', function() {
   buildForProduction = true;
   runSequence(
      'cleanDist',
      'moveImages',
      'moveFonts',
      'minifyJS',
      'compileCSS',
      'compileAllPUG'
   );
});