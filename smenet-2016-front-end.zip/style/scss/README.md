# scss

This is where the main scss file that pulls all includes goes.

main.scss should be the only Sass file from the whole code base not to begin with an underscore. This file should not contain anything but `@import` and comments.

