# pug

This is where pug files for pages should be kept.
Please change the title on index.pug to the client/project name
