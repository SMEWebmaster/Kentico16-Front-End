# includes

This is where smaller, discrete UI elements are kept for easy editing across all pages that contain these elements.
This includes global items like the main header, footer, page meta, etc.

Any calls to script libraries, css files, meta tags, etc. should be added to _head.pug and not individual pages
