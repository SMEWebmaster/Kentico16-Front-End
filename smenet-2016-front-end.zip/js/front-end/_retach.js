$(document).ready(function() {
  $('.header-navMain-nav li.search > div').retach({
    destination: '.header-main-toggles--search',
    mediaQuery: 849
  });

  $('.header-main-nav > ul > li').not(':has(> div)').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
  });

  $('.header-main-nav > ul > li').has('> div').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
    movedClass: 'mega'
  });

  $('.header-util-nav > ul > li').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
  });

  $('.header-navMain-nav > ul > li:not(.search)').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
    movedClass: 'mega'
  });
});



(function($) {
  $.fn.retach = function(opts) {
    var defaults = {
      destination: 'body',
      mediaQuery: 1023,
      movedClass: 'is-moved',
      prependAppend: 'append'
    };
    var options = $.extend({}, defaults, opts);

    var $items = this;
    var $destination = $(options.destination);
    var mediaQuery = options.mediaQuery;
    var movedClass = options.movedClass;
    var $prependAppend = options.prependAppend;

    var placeholderID = Math.floor((Math.random() * 10000) + 1) + Math.floor((Math.random() * 10000) + 1);
    var $placeholder = $('<i class="placeholder" data-placeholderID="' + placeholderID + '" />');

    function moveItems() {
      if ($('i[data-placeholderID="' + placeholderID + '"]').length <= 0) {
        $items.first().before($placeholder);
      }
      if (window.matchMedia("(max-width: " + mediaQuery + "px)").matches) {
        if ($prependAppend == 'append') {
          $destination.append($items);
        } else {
          $destination.prepend($items);
        }

        $items.addClass(movedClass);
      } else {
        $placeholder.after($items);
        $items.removeClass(movedClass);
      }
    }

    moveItems();
    $(window).resize(function() {
      moveItems();
    });
    return $items;
  };
}(jQuery));