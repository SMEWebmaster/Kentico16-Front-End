$(document).ready(function() {
    bindDoubleTap();

    $(window).on('resize orientationchange', function() {
        bindDoubleTap();
    });
});

function bindDoubleTap() {
    if (window.matchMedia("(max-width: 849px)").matches) {
        $('.header-navMain-nav > ul > li:has(div)').off();
    } else {
        $('.header-navMain-nav > ul > li:has(div)').doubleTapToGo();
    }
}

/*
    By Osvaldas Valutis, www.osvaldas.info
    Available for use under the MIT License
*/
;
(function($, window, document, undefined) {
    $.fn.doubleTapToGo = function(params) {
        if (!('ontouchstart' in window) &&
            !navigator.msMaxTouchPoints &&
            !navigator.userAgent.toLowerCase().match(/windows phone os 7/i)) return false;

        this.each(function() {
            var curItem = false;

            $(this).on('click', function(e) {
                var item = $(this);
                if (item[0] != curItem[0]) {
                    e.preventDefault();
                    curItem = item;
                }
            });

            $(document).on('click touchstart MSPointerDown', function(e) {
                var resetItem = true,
                    parents = $(e.target).parents();

                for (var i = 0; i < parents.length; i++)
                    if (parents[i] == curItem[0])
                        resetItem = false;

                if (resetItem)
                    curItem = false;
            });
        });
        return this;
    };
})(jQuery, window, document);
$(document).ready(function() {
    // Show on click
    $('.searchDrop span').on('click',function(e) {
        if ($(this).closest('.searchDrop').hasClass('active')) {
            $(this).closest('.searchDrop').removeClass('active');
            $(this).closest('.searchDrop').find('*').removeClass('active');
        } else {
            $(this).closest('.searchDrop').addClass('active');
        }
        $('.searchDrop').not($(this).closest('.searchDrop')).removeClass('active');
        $('.header-main-toggles--nav').removeClass('active').find('*').removeClass('active');
        $('html').removeClass('menu-open');
    });

    $('.searchDrop').mouseout(function() {
        var $this = $(this);
        setTimeout(function() {
            if (!($this.is(":hover"))) {
                $this.removeClass('active');
                $this.find('input').blur();
            }
        }, 250);
    });

    $(document).on('click touchend', function(e) {
        var $target = $(e.target);
        if (($target.parents('.searchDrop').length <= 0)) {
            $('.searchDrop').removeClass('active');
            $('.searchDrop').find('input').blur();
        }
    });
});
$(document).ready(function() {
    $('.header-main-toggles--nav span').click(function() {
        if ($('html').hasClass('menu-open')) {
            $('.header-main-toggles--nav').removeClass('active');
            $('.mobileDrawer').children('*').removeClass('active');
            $('html').removeClass('menu-open');
        }
        else {
            $('.header-main-toggles--nav').addClass('active');
            $('html').addClass('menu-open');
        }
        menuHeight();
    });
    $(document).on('click touchstart', '.mobileDrawer > ul > li > a', function(e) {
        e.stopPropagation();
    });
    $(document).on('click touchend', '.mobileDrawer > ul > li.mega', function(e) {
        $(this).closest('li.mega').addClass('active');
        $(this).closest('ul').addClass('active');
        $(this).siblings('li').removeClass('active');
        e.stopPropagation();
    });
    $(document).on('click touchend', '.mobileDrawer > ul > li > div', function(e) {
        $(this).parents('li').removeClass('active');
        $(this).parents('ul').removeClass('active');
        e.stopPropagation();
    });
    $(document).on('click touchend', '.mobileDrawer > ul > li > div ul', function(e) {
        e.stopPropagation();
    });
});

$(window).on('resize orientationchange', function() {
    menuHeight();
    if (window.matchMedia("(max-width: 849px)").matches) {
        $('.header-main-toggles--nav').removeClass('active');
        $('.mobileDrawer').children().removeClass('active');
        $('html').removeClass('menu-open');
    }
});

function menuHeight() {
    if (window.matchMedia("(max-width: 849px)").matches) {
        var windowHeight = $(window).outerHeight();
        var headerHeight = $('.header').outerHeight();
        var menuHeight = windowHeight - headerHeight;

        $('.mobileDrawer').css('max-height', menuHeight);
        $('.mobileDrawer > ul > li > div').css('max-height', menuHeight);
    }
    else {
        $('.mobileDrawer').css('max-height', '');
        $('.mobileDrawer > ul > li > div').css('max-height', '');
    }
}
$(document).ready(function() {
    $('.modalSearch-trigger, .modalSearch-trigger a').on('click touchend', function(e) {
        e.preventDefault();

        $('.modalSearch').addClass('active');
        $('html').addClass('modal-open');

        $('.header-main-toggles--nav').removeClass('active');

        setTimeout(function() {
            $('.mobileDrawer').removeClass('active');
            $('.mobileDrawer ul').removeClass('active');
            $('.mobileDrawer li').removeClass('active');
            $('html').removeClass('menu-open');
        }, 200);
    });

    $('.modalSearch-close').on('click touchend', function() {
        $('.modalSearch').removeClass('active');
        $('html').removeClass('modal-open');
    });
});
$(document).ready(function() {
  $('.header-navMain-nav li.search > div').retach({
    destination: '.header-main-toggles--search',
    mediaQuery: 849
  });

  $('.header-main-nav > ul > li').not(':has(> div)').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
  });

  $('.header-main-nav > ul > li').has('> div').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
    movedClass: 'mega'
  });

  $('.header-util-nav > ul > li').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
  });

  $('.header-navMain-nav > ul > li:not(.search)').retach({
    destination: '.mobileDrawer > ul',
    mediaQuery: 849,
    movedClass: 'mega'
  });
});



(function($) {
  $.fn.retach = function(opts) {
    var defaults = {
      destination: 'body',
      mediaQuery: 1023,
      movedClass: 'is-moved',
      prependAppend: 'append'
    };
    var options = $.extend({}, defaults, opts);

    var $items = this;
    var $destination = $(options.destination);
    var mediaQuery = options.mediaQuery;
    var movedClass = options.movedClass;
    var $prependAppend = options.prependAppend;

    var placeholderID = Math.floor((Math.random() * 10000) + 1) + Math.floor((Math.random() * 10000) + 1);
    var $placeholder = $('<i class="placeholder" data-placeholderID="' + placeholderID + '" />');

    function moveItems() {
      if ($('i[data-placeholderID="' + placeholderID + '"]').length <= 0) {
        $items.first().before($placeholder);
      }
      if (window.matchMedia("(max-width: " + mediaQuery + "px)").matches) {
        if ($prependAppend == 'append') {
          $destination.append($items);
        } else {
          $destination.prepend($items);
        }

        $items.addClass(movedClass);
      } else {
        $placeholder.after($items);
        $items.removeClass(movedClass);
      }
    }

    moveItems();
    $(window).resize(function() {
      moveItems();
    });
    return $items;
  };
}(jQuery));