$(document).ready(function() {
    $('.modalSearch-trigger, .modalSearch-trigger a').on('click touchend', function(e) {
        e.preventDefault();

        $('.modalSearch').addClass('active');
        $('html').addClass('modal-open');

        $('.header-main-toggles--nav').removeClass('active');

        setTimeout(function() {
            $('.mobileDrawer').removeClass('active');
            $('.mobileDrawer ul').removeClass('active');
            $('.mobileDrawer li').removeClass('active');
            $('html').removeClass('menu-open');
        }, 200);
    });

    $('.modalSearch-close').on('click touchend', function() {
        $('.modalSearch').removeClass('active');
        $('html').removeClass('modal-open');
    });
});