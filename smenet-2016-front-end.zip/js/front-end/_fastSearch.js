$(document).ready(function() {
    // Show on click
    $('.searchDrop span').on('click',function(e) {
        if ($(this).closest('.searchDrop').hasClass('active')) {
            $(this).closest('.searchDrop').removeClass('active');
            $(this).closest('.searchDrop').find('*').removeClass('active');
        } else {
            $(this).closest('.searchDrop').addClass('active');
        }
        $('.searchDrop').not($(this).closest('.searchDrop')).removeClass('active');
        $('.header-main-toggles--nav').removeClass('active').find('*').removeClass('active');
        $('html').removeClass('menu-open');
    });

    $('.searchDrop').mouseout(function() {
        var $this = $(this);
        setTimeout(function() {
            if (!($this.is(":hover"))) {
                $this.removeClass('active');
                $this.find('input').blur();
            }
        }, 250);
    });

    $(document).on('click touchend', function(e) {
        var $target = $(e.target);
        if (($target.parents('.searchDrop').length <= 0)) {
            $('.searchDrop').removeClass('active');
            $('.searchDrop').find('input').blur();
        }
    });
});