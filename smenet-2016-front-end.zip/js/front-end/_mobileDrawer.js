$(document).ready(function() {
    $('.header-main-toggles--nav span').click(function() {
        if ($('html').hasClass('menu-open')) {
            $('.header-main-toggles--nav').removeClass('active');
            $('.mobileDrawer').children('*').removeClass('active');
            $('html').removeClass('menu-open');
        }
        else {
            $('.header-main-toggles--nav').addClass('active');
            $('html').addClass('menu-open');
        }
        menuHeight();
    });
    $(document).on('click touchstart', '.mobileDrawer > ul > li > a', function(e) {
        e.stopPropagation();
    });
    $(document).on('click touchend', '.mobileDrawer > ul > li.mega', function(e) {
        $(this).closest('li.mega').addClass('active');
        $(this).closest('ul').addClass('active');
        $(this).siblings('li').removeClass('active');
        e.stopPropagation();
    });
    $(document).on('click touchend', '.mobileDrawer > ul > li > div', function(e) {
        $(this).parents('li').removeClass('active');
        $(this).parents('ul').removeClass('active');
        e.stopPropagation();
    });
    $(document).on('click touchend', '.mobileDrawer > ul > li > div ul', function(e) {
        e.stopPropagation();
    });
});

$(window).on('resize orientationchange', function() {
    menuHeight();
    if (window.matchMedia("(max-width: 849px)").matches) {
        $('.header-main-toggles--nav').removeClass('active');
        $('.mobileDrawer').children().removeClass('active');
        $('html').removeClass('menu-open');
    }
});

function menuHeight() {
    if (window.matchMedia("(max-width: 849px)").matches) {
        var windowHeight = $(window).outerHeight();
        var headerHeight = $('.header').outerHeight();
        var menuHeight = windowHeight - headerHeight;

        $('.mobileDrawer').css('max-height', menuHeight);
        $('.mobileDrawer > ul > li > div').css('max-height', menuHeight);
    }
    else {
        $('.mobileDrawer').css('max-height', '');
        $('.mobileDrawer > ul > li > div').css('max-height', '');
    }
}